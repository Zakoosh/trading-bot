import pandas as pd
from app.analysis.engine import AnalyticalEngine
from app.storage.state_store import StateStore

# Usage: python backtest.py path/to/data.csv SYMBOL TIMEFRAME
import sys

def main():
    if len(sys.argv) < 4:
        print("Usage: python backtest.py <csv> <symbol> <timeframe>")
        return
    csv, symbol, timeframe = sys.argv[1:4]
    df = pd.read_csv(csv).sort_values("ts")
    store = StateStore(":memory:")
    eng = AnalyticalEngine(store, equity=10000, risk_per_trade=0.005)
    last_dec = None
    for _, r in df.iterrows():
        store.insert_candle((symbol, timeframe, int(r['ts']), float(r['open']), float(r['high']), float(r['low']), float(r['close']), float(r['volume'])))
        last_dec = eng.on_candle(symbol, timeframe)
    print("Last decision:", last_dec)

if __name__ == "__main__":
    main()
