from fastapi import FastAPI, HTTPException
from .schemas import TradingViewAlert, Decision, ToggleAuto, UpdateParams, PositionSnapshot
from .storage.state_store import StateStore
from .analysis.engine import AnalyticalEngine
from .execution.executor import Executor
from .analysis.position_state import PositionState
from . import config

app = FastAPI(title="Trading Bot Analytical Core", version="1.0.0")
store = StateStore("state.db")
engine = AnalyticalEngine(store, equity=config.ACCOUNT_EQUITY, risk_per_trade=config.DEFAULT_RISK_PER_TRADE)
executor = Executor(store, paper=True)

def validate_secret(secret: str):
    if secret != config.WEBHOOK_SECRET:
        raise HTTPException(status_code=401, detail="invalid secret")

@app.get("/health")
def health():
    return {"ok": True}

@app.post("/webhook/tradingview", response_model=Decision)
def tradingview_webhook(alert: TradingViewAlert):
    validate_secret(alert.secret)
    store.insert_candle((alert.symbol, alert.timeframe, alert.ts, alert.open, alert.high, alert.low, alert.close, alert.volume))
    dec = engine.on_candle(alert.symbol, alert.timeframe)
    signal = dec.get("signal", "HOLD")
    resp = Decision(
        symbol=alert.symbol,
        timeframe=alert.timeframe,
        signal=signal,
        confidence=float(dec.get("confidence", 0.3)),
        reason=dec.get("reason", "n/a"),
        stop_loss=dec.get("stop"),
        take_profit=None,
        size=dec.get("size"),
        meta={"entry": dec.get("entry"), "ts": alert.ts}
    )
    # Auto exec guardrails
    if config.AUTO_TRADING and signal in ("BUY","SELL"):
        risk_used = store.get_metric("risk_used_today", 0.0)
        if risk_used >= config.DAILY_RISK_LIMIT:
            resp.meta["skipped_execution"] = "daily risk limit reached"
            return resp
        if not executor.can_open_more(config.MAX_CONCURRENT_POS):
            resp.meta["skipped_execution"] = "max concurrent positions reached"
            return resp
        if not resp.size or resp.size <= 0:
            resp.meta["skipped_execution"] = "size=0"
            return resp
        ex = executor.open_position(alert.symbol, side=signal, entry=resp.meta["entry"], stop=resp.stop_loss, size=resp.size)
        store.set_metric("risk_used_today", risk_used + float(config.DEFAULT_RISK_PER_TRADE))
        resp.meta["execution"] = dict(ex)
    return resp

@app.post("/toggle-auto")
def toggle_auto(t: ToggleAuto):
    store.set_metric("auto_enabled_runtime", 1.0 if t.enabled else 0.0)
    return {"auto_enabled": t.enabled}

@app.post("/params")
def update_params(p: UpdateParams):
    if p.account_equity is not None:
        engine.equity = float(p.account_equity)
    if p.risk_per_trade is not None:
        engine.risk_per_trade = float(p.risk_per_trade)
    if p.daily_risk_limit is not None:
        store.set_metric("daily_risk_limit_runtime", float(p.daily_risk_limit))
    if p.max_concurrent_pos is not None:
        store.set_metric("max_concurrent_runtime", float(p.max_concurrent_pos))
    return {"ok": True, "params": p.model_dump()}

@app.get("/position/{symbol}", response_model=PositionSnapshot)
def position(symbol: str):
    pos = store.get_position(symbol)
    if not pos:
        return PositionSnapshot(symbol=symbol, state=PositionState.FLAT)
    return PositionSnapshot(**pos)
