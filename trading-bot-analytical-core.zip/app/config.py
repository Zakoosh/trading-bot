import os
from dotenv import load_dotenv
load_dotenv()

WEBHOOK_SECRET = os.getenv("WEBHOOK_SECRET", "my_dev_secret_123")
AUTO_TRADING = os.getenv("AUTO_TRADING", "false").lower() == "true"
DAILY_RISK_LIMIT = float(os.getenv("DAILY_RISK_LIMIT", "0.02"))  # 2% of equity
MAX_CONCURRENT_POS = int(os.getenv("MAX_CONCURRENT_POS", "3"))
ACCOUNT_EQUITY = float(os.getenv("ACCOUNT_EQUITY", "10000"))
DEFAULT_RISK_PER_TRADE = float(os.getenv("DEFAULT_RISK_PER_TRADE", "0.005"))  # 0.5%
