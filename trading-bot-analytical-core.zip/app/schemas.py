from pydantic import BaseModel, Field
from typing import Optional, Literal, Dict, Any

class TradingViewAlert(BaseModel):
    secret: str
    symbol: str
    timeframe: str
    ts: int  # unix ms
    open: float
    high: float
    low: float
    close: float
    volume: float
    htf_timeframe: Optional[str] = None
    htf_close: Optional[float] = None
    htf_ema200: Optional[float] = None

class Decision(BaseModel):
    symbol: str
    timeframe: str
    signal: Literal["BUY","SELL","HOLD"]
    confidence: float = Field(ge=0, le=1)
    reason: str
    stop_loss: Optional[float] = None
    take_profit: Optional[float] = None
    size: Optional[float] = None
    meta: Dict[str, Any] = {}

class ToggleAuto(BaseModel):
    enabled: bool

class UpdateParams(BaseModel):
    daily_risk_limit: Optional[float] = None
    max_concurrent_pos: Optional[int] = None
    risk_per_trade: Optional[float] = None
    account_equity: Optional[float] = None

class PositionSnapshot(BaseModel):
    symbol: str
    side: Optional[str] = None
    entry: Optional[float] = None
    stop: Optional[float] = None
    size: Optional[float] = None
    opened_at: Optional[int] = None
    state: str
