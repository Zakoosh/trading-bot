import time
from ..storage.state_store import StateStore
from ..analysis.position_state import PositionState

class ExecutionResult(dict):
    pass

class Executor:
    def __init__(self, store: StateStore, paper: bool = True):
        self.store = store
        self.paper = paper

    def can_open_more(self, max_concurrent: int) -> bool:
        c = self.store.conn.cursor()
        c.execute("SELECT COUNT(*) FROM positions WHERE state!='FLAT'")
        n = c.fetchone()[0]
        return n < max_concurrent

    def open_position(self, symbol: str, side: str, entry: float, stop: float, size: float) -> ExecutionResult:
        now = int(time.time()*1000)
        self.store.upsert_position({
            "symbol": symbol,
            "side": side,
            "entry": entry,
            "stop": stop,
            "size": size,
            "opened_at": now,
            "state": PositionState.LONG if side=='BUY' else PositionState.SHORT
        })
        return ExecutionResult(status="FILLED" if self.paper else "SENT", symbol=symbol, side=side, entry=entry, stop=stop, size=size, ts=now)

    def close_position(self, symbol: str, reason: str) -> ExecutionResult:
        pos = self.store.get_position(symbol)
        if not pos or pos["state"]=="FLAT":
            return ExecutionResult(status="NO_POSITION", symbol=symbol, reason=reason)
        pos["state"] = PositionState.FLAT
        pos["side"] = None
        pos["entry"] = None
        pos["stop"] = None
        pos["size"] = None
        self.store.upsert_position(pos)
        return ExecutionResult(status="CLOSED", symbol=symbol, reason=reason)
