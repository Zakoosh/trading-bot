import sqlite3
from typing import Optional, Dict, Any, List, Tuple

class StateStore:
    def __init__(self, path: str = "state.db"):
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self._init()

    def _init(self):
        c = self.conn.cursor()
        c.execute('''
            CREATE TABLE IF NOT EXISTS candles (
                symbol TEXT,
                timeframe TEXT,
                ts INTEGER,
                open REAL, high REAL, low REAL, close REAL, volume REAL,
                PRIMARY KEY(symbol, timeframe, ts)
            );
        ''')
        c.execute('''
            CREATE TABLE IF NOT EXISTS positions (
                symbol TEXT PRIMARY KEY,
                side TEXT,
                entry REAL,
                stop REAL,
                size REAL,
                opened_at INTEGER,
                state TEXT
            );
        ''')
        c.execute('''
            CREATE TABLE IF NOT EXISTS metrics (
                key TEXT PRIMARY KEY,
                value REAL
            );
        ''')
        self.conn.commit()

    def insert_candle(self, row: Tuple):
        c = self.conn.cursor()
        c.execute('''
        INSERT OR REPLACE INTO candles(symbol,timeframe,ts,open,high,low,close,volume)
        VALUES(?,?,?,?,?,?,?,?)
        ''', row)
        self.conn.commit()

    def fetch_recent(self, symbol: str, timeframe: str, limit: int = 300):
        c = self.conn.cursor()
        c.execute('''
        SELECT ts, open, high, low, close, volume FROM candles
        WHERE symbol=? AND timeframe=?
        ORDER BY ts DESC
        LIMIT ?
        ''', (symbol, timeframe, limit))
        rows = c.fetchall()
        return rows[::-1]  # chronological

    def get_position(self, symbol: str) -> Optional[Dict[str,Any]]:
        c = self.conn.cursor()
        c.execute('SELECT symbol, side, entry, stop, size, opened_at, state FROM positions WHERE symbol=?', (symbol,))
        r = c.fetchone()
        if not r: return None
        keys = ["symbol","side","entry","stop","size","opened_at","state"]
        return dict(zip(keys, r))

    def upsert_position(self, pos: Dict[str,Any]):
        c = self.conn.cursor()
        c.execute('''
        INSERT INTO positions(symbol, side, entry, stop, size, opened_at, state)
        VALUES(?,?,?,?,?,?,?)
        ON CONFLICT(symbol) DO UPDATE SET
          side=excluded.side,
          entry=excluded.entry,
          stop=excluded.stop,
          size=excluded.size,
          opened_at=excluded.opened_at,
          state=excluded.state
        ''', (pos["symbol"], pos.get("side"), pos.get("entry"), pos.get("stop"), pos.get("size"), pos.get("opened_at"), pos.get("state")))
        self.conn.commit()

    def set_metric(self, key: str, value: float):
        c = self.conn.cursor()
        c.execute('''
        INSERT INTO metrics(key, value) VALUES(?,?)
        ON CONFLICT(key) DO UPDATE SET value=excluded.value
        ''', (key, value))
        self.conn.commit()

    def get_metric(self, key: str, default: float = 0.0) -> float:
        c = self.conn.cursor()
        c.execute('SELECT value FROM metrics WHERE key=?', (key,))
        r = c.fetchone()
        return r[0] if r else default
