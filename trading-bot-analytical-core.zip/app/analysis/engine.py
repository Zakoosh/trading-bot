import pandas as pd
import numpy as np
from .strategies.rsi_macd_confluence import RSIMACDConfluence
from .risk import atr, position_size
from ..storage.state_store import StateStore

class AnalyticalEngine:
    def __init__(self, store: StateStore, equity: float, risk_per_trade: float):
        self.store = store
        self.strategy = RSIMACDConfluence()
        self.equity = equity
        self.risk_per_trade = risk_per_trade

    def on_candle(self, symbol: str, timeframe: str):
        rows = self.store.fetch_recent(symbol, timeframe, limit=400)
        if len(rows) < 60:
            return {"signal":"HOLD","reason":"need more data"}
        df = pd.DataFrame(rows, columns=["ts","open","high","low","close","volume"])
        sig, conf, reason = self.strategy.last_signal(df)
        _atr = atr(df["high"].values, df["low"].values, df["close"].values, period=14)
        last_atr = float(_atr[-1]) if not np.isnan(_atr[-1]) else None
        entry = float(df["close"].iloc[-1])
        if last_atr is None or last_atr == 0:
            return {"signal":"HOLD","reason":"ATR unavailable", "confidence":conf}
        if sig == "BUY":
            stop = entry - 1.5*last_atr
            size = position_size(self.equity, self.risk_per_trade, entry, stop)
            return {"signal":"BUY","confidence":conf,"reason":reason,"entry":entry,"stop":stop,"size":size}
        if sig == "SELL":
            stop = entry + 1.5*last_atr
            size = position_size(self.equity, self.risk_per_trade, entry, stop)
            return {"signal":"SELL","confidence":conf,"reason":reason,"entry":entry,"stop":stop,"size":size}
        return {"signal":"HOLD","confidence":conf,"reason":reason}
