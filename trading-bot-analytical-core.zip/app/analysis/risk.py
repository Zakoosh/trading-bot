from typing import Tuple
import numpy as np

def atr(high, low, close, period=14):
    high = np.asarray(high, dtype=float)
    low = np.asarray(low, dtype=float)
    close = np.asarray(close, dtype=float)
    tr = np.maximum(high[1:], close[:-1]) - np.minimum(low[1:], close[:-1])
    tr = np.abs(tr)
    atr_vals = np.empty_like(close, dtype=float)
    atr_vals[:] = np.nan
    if len(tr) > 0:
        atr_vals[0] = tr[0]
    for i in range(1, len(close)):
        if i-1 < len(tr):
            prev = atr_vals[i-1] if not np.isnan(atr_vals[i-1]) else tr[i-1]
            atr_vals[i] = (prev*(period-1) + tr[i-1]) / period
    return atr_vals

def position_size(equity: float, risk_pct: float, entry: float, stop: float) -> float:
    risk_amt = equity * risk_pct
    per_unit_risk = abs(entry - stop)
    if per_unit_risk <= 0:
        return 0.0
    size = risk_amt / per_unit_risk
    return max(0.0, float(size))
