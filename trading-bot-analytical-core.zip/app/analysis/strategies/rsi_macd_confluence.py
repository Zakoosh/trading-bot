import pandas as pd
from ta.momentum import RSIIndicator
from ta.trend import MACD, EMAIndicator

class RSIMACDConfluence:
    def __init__(self, rsi_len=14, rsi_buy=32, rsi_sell=68,
                 macd_fast=12, macd_slow=26, macd_signal=9,
                 ema_len=200):
        self.rsi_len = rsi_len
        self.rsi_buy = rsi_buy
        self.rsi_sell = rsi_sell
        self.macd_fast = macd_fast
        self.macd_slow = macd_slow
        self.macd_signal = macd_signal
        self.ema_len = ema_len

    def compute(self, df: pd.DataFrame):
        rsi = RSIIndicator(close=df['close'], window=self.rsi_len).rsi()
        macd = MACD(close=df['close'], window_fast=self.macd_fast, window_slow=self.macd_slow, window_sign=self.macd_signal)
        ema200 = EMAIndicator(close=df['close'], window=self.ema_len).ema_indicator()
        out = df.copy()
        out['rsi'] = rsi
        out['macd'] = macd.macd()
        out['macd_signal'] = macd.macd_signal()
        out['macd_hist'] = macd.macd_diff()
        out['ema200'] = ema200
        return out

    def last_signal(self, df: pd.DataFrame):
        df = self.compute(df)
        if len(df) < 60: 
            return "HOLD", 0.2, "insufficient data"

        last = df.iloc[-1]
        prev = df.iloc[-2]

        buy_cond = (last['rsi'] <= self.rsi_buy) and (prev['macd'] < prev['macd_signal']) and (last['macd'] > last['macd_signal']) and (last['close'] > last['ema200'])
        sell_cond = (last['rsi'] >= self.rsi_sell) and (prev['macd'] > prev['macd_signal']) and (last['macd'] < last['macd_signal']) and (last['close'] < last['ema200'])

        if buy_cond:
            conf = float(min(1.0, 0.55 + (self.rsi_buy - last['rsi'])/120 + max(0.0, last['macd']-last['macd_signal'])/2))
            return "BUY", conf, "RSI oversold + MACD bull cross + above EMA200"
        if sell_cond:
            conf = float(min(1.0, 0.55 + (last['rsi'] - self.rsi_sell)/120 + max(0.0, last['macd_signal']-last['macd'])/2))
            return "SELL", conf, "RSI overbought + MACD bear cross + below EMA200"
        return "HOLD", 0.3, "no confluence"
