# Trading Bot Analytical Core (Integrated)

هذا لبّ الذكاء التحليلي مدموج داخل الباكيند. يستقبل Alerts من TradingView، يخزن الشموع، يحسب مؤشرات (RSI+MACD+EMA200)، يقرر (BUY/SELL/HOLD)، و(اختياريًا) ينفّذ على وضع Paper مع حواجز أمان.

## التثبيت
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
export WEBHOOK_SECRET="my_dev_secret_123"
export AUTO_TRADING=false   # true لتفعيل التنفيذ الآلي
uvicorn app.main:app --reload --port 8000
```

## نقطة الويب هوك
POST /webhook/tradingview
يستقبل JSON (انظر pine/alert_message_template.pine) ويتحقق من السر.

## تغيير البارامترات أثناء التشغيل
- POST /params لتحديث equity أو risk_per_trade وغيرها
- POST /toggle-auto لتفعيل/إيقاف التنفيذ الآلي (runtime flag)

## الحالات/المراكز
- GET /position/{symbol} يرجّع حالة المركز الحالية على الرمز.

## باك تست سريع
```bash
python backtest.py data.csv BTCUSDT 1h
```
حيث يحتوي data.csv الأعمدة: ts,open,high,low,close,volume (ترتيب زمني متصاعد).

## ملاحظات
- التنفيذ الحقيقي يتطلب ربط Broker (Binance/Alpaca/IBKR). الموديول الحالي app/execution/executor.py يعمل Paper فقط.
- الاستراتيجية الافتراضية: RSI + MACD + EMA200، مع وقف خسارة مبني على ATR 1.5x وحجم مركز محسوب كنسبة مخاطرة من رأس المال.
